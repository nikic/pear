<?php

/**
 * This class is only retained for backwards compatibility. Use PHPParser_PrettyPrinter_Default instead.
 *
 * @deprecated
 */
class PHPParser_PrettyPrinter_Zend extends PHPParser_PrettyPrinter_Default
{
}