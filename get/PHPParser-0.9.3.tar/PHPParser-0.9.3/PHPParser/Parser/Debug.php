<?php

/* This is an automatically GENERATED file, which should not be manually edited.
 * Instead edit one of the following:
 *  * the grammar file grammar/zend_language_parser.phpy
 *  * the parser skeleton grammar/kymacc.php.parser
 *  * the preprocessing script grammar/rebuildParser.php
 *
 * The skeleton for this parser was written by Moriyoshi Koizumi and is based on
 * the work by Masato Bito and is in the PUBLIC DOMAIN.
 */
class PHPParser_Parser_Debug extends PHPParser_Parser
{
    protected static $yyproduction = array(
        "start : start",
        "start : top_statement_list",
        "top_statement_list : top_statement_list top_statement",
        "top_statement_list : /* empty */",
        "namespace_name : T_STRING",
        "namespace_name : namespace_name T_NS_SEPARATOR T_STRING",
        "top_statement : statement",
        "top_statement : function_declaration_statement",
        "top_statement : class_declaration_statement",
        "top_statement : T_HALT_COMPILER",
        "top_statement : T_NAMESPACE namespace_name ';'",
        "top_statement : T_NAMESPACE namespace_name '{' top_statement_list '}'",
        "top_statement : T_NAMESPACE '{' top_statement_list '}'",
        "top_statement : T_USE use_declarations ';'",
        "top_statement : T_CONST constant_declaration_list ';'",
        "use_declarations : use_declarations ',' use_declaration",
        "use_declarations : use_declaration",
        "use_declaration : namespace_name",
        "use_declaration : namespace_name T_AS T_STRING",
        "use_declaration : T_NS_SEPARATOR namespace_name",
        "use_declaration : T_NS_SEPARATOR namespace_name T_AS T_STRING",
        "constant_declaration_list : constant_declaration_list ',' constant_declaration",
        "constant_declaration_list : constant_declaration",
        "constant_declaration : T_STRING '=' static_scalar",
        "inner_statement_list : inner_statement_list inner_statement",
        "inner_statement_list : /* empty */",
        "inner_statement : statement",
        "inner_statement : function_declaration_statement",
        "inner_statement : class_declaration_statement",
        "inner_statement : T_HALT_COMPILER",
        "statement : '{' inner_statement_list '}'",
        "statement : T_IF parentheses_expr statement elseif_list else_single",
        "statement : T_IF parentheses_expr ':' inner_statement_list new_elseif_list new_else_single T_ENDIF ';'",
        "statement : T_WHILE parentheses_expr while_statement",
        "statement : T_DO statement T_WHILE parentheses_expr ';'",
        "statement : T_FOR '(' for_expr ';' for_expr ';' for_expr ')' for_statement",
        "statement : T_SWITCH parentheses_expr switch_case_list",
        "statement : T_BREAK ';'",
        "statement : T_BREAK expr ';'",
        "statement : T_CONTINUE ';'",
        "statement : T_CONTINUE expr ';'",
        "statement : T_RETURN ';'",
        "statement : T_RETURN expr ';'",
        "statement : yield_expr ';'",
        "statement : T_GLOBAL global_var_list ';'",
        "statement : T_STATIC static_var_list ';'",
        "statement : T_ECHO expr_list ';'",
        "statement : T_INLINE_HTML",
        "statement : expr ';'",
        "statement : T_UNSET '(' variables_list ')' ';'",
        "statement : T_FOREACH '(' expr T_AS foreach_variable ')' foreach_statement",
        "statement : T_FOREACH '(' expr T_AS variable T_DOUBLE_ARROW foreach_variable ')' foreach_statement",
        "statement : T_DECLARE '(' declare_list ')' declare_statement",
        "statement : ';'",
        "statement : T_TRY '{' inner_statement_list '}' catches optional_finally",
        "statement : T_THROW expr ';'",
        "statement : T_GOTO T_STRING ';'",
        "statement : T_STRING ':'",
        "catches : /* empty */",
        "catches : catches catch",
        "catch : T_CATCH '(' name T_VARIABLE ')' '{' inner_statement_list '}'",
        "optional_finally : /* empty */",
        "optional_finally : T_FINALLY '{' inner_statement_list '}'",
        "variables_list : variable",
        "variables_list : variables_list ',' variable",
        "optional_ref : /* empty */",
        "optional_ref : '&'",
        "function_declaration_statement : T_FUNCTION optional_ref T_STRING '(' parameter_list ')' '{' inner_statement_list '}'",
        "class_declaration_statement : class_entry_type T_STRING extends_from implements_list '{' class_statement_list '}'",
        "class_declaration_statement : T_INTERFACE T_STRING interface_extends_list '{' class_statement_list '}'",
        "class_declaration_statement : T_TRAIT T_STRING '{' class_statement_list '}'",
        "class_entry_type : T_CLASS",
        "class_entry_type : T_ABSTRACT T_CLASS",
        "class_entry_type : T_FINAL T_CLASS",
        "extends_from : /* empty */",
        "extends_from : T_EXTENDS name",
        "interface_extends_list : /* empty */",
        "interface_extends_list : T_EXTENDS name_list",
        "implements_list : /* empty */",
        "implements_list : T_IMPLEMENTS name_list",
        "name_list : name",
        "name_list : name_list ',' name",
        "for_statement : statement",
        "for_statement : ':' inner_statement_list T_ENDFOR ';'",
        "foreach_statement : statement",
        "foreach_statement : ':' inner_statement_list T_ENDFOREACH ';'",
        "declare_statement : statement",
        "declare_statement : ':' inner_statement_list T_ENDDECLARE ';'",
        "declare_list : declare_list_element",
        "declare_list : declare_list ',' declare_list_element",
        "declare_list_element : T_STRING '=' static_scalar",
        "switch_case_list : '{' case_list '}'",
        "switch_case_list : '{' ';' case_list '}'",
        "switch_case_list : ':' case_list T_ENDSWITCH ';'",
        "switch_case_list : ':' ';' case_list T_ENDSWITCH ';'",
        "case_list : /* empty */",
        "case_list : case_list case",
        "case : T_CASE expr case_separator inner_statement_list",
        "case : T_DEFAULT case_separator inner_statement_list",
        "case_separator : ':'",
        "case_separator : ';'",
        "while_statement : statement",
        "while_statement : ':' inner_statement_list T_ENDWHILE ';'",
        "elseif_list : /* empty */",
        "elseif_list : elseif_list elseif",
        "elseif : T_ELSEIF parentheses_expr statement",
        "new_elseif_list : /* empty */",
        "new_elseif_list : new_elseif_list new_elseif",
        "new_elseif : T_ELSEIF parentheses_expr ':' inner_statement_list",
        "else_single : /* empty */",
        "else_single : T_ELSE statement",
        "new_else_single : /* empty */",
        "new_else_single : T_ELSE ':' inner_statement_list",
        "foreach_variable : variable",
        "foreach_variable : '&' variable",
        "foreach_variable : list_expr",
        "parameter_list : non_empty_parameter_list",
        "parameter_list : /* empty */",
        "non_empty_parameter_list : parameter",
        "non_empty_parameter_list : non_empty_parameter_list ',' parameter",
        "parameter : optional_class_type optional_ref T_VARIABLE",
        "parameter : optional_class_type optional_ref T_VARIABLE '=' static_scalar",
        "optional_class_type : /* empty */",
        "optional_class_type : name",
        "optional_class_type : T_ARRAY",
        "optional_class_type : T_CALLABLE",
        "argument_list : '(' ')'",
        "argument_list : '(' non_empty_argument_list ')'",
        "argument_list : '(' yield_expr ')'",
        "non_empty_argument_list : argument",
        "non_empty_argument_list : non_empty_argument_list ',' argument",
        "argument : expr",
        "argument : '&' variable",
        "global_var_list : global_var_list ',' global_var",
        "global_var_list : global_var",
        "global_var : T_VARIABLE",
        "global_var : '$' variable",
        "global_var : '$' '{' expr '}'",
        "static_var_list : static_var_list ',' static_var",
        "static_var_list : static_var",
        "static_var : T_VARIABLE",
        "static_var : T_VARIABLE '=' static_scalar",
        "class_statement_list : class_statement_list class_statement",
        "class_statement_list : /* empty */",
        "class_statement : variable_modifiers property_declaration_list ';'",
        "class_statement : T_CONST constant_declaration_list ';'",
        "class_statement : method_modifiers T_FUNCTION optional_ref T_STRING '(' parameter_list ')' method_body",
        "class_statement : T_USE name_list trait_adaptations",
        "trait_adaptations : ';'",
        "trait_adaptations : '{' trait_adaptation_list '}'",
        "trait_adaptation_list : /* empty */",
        "trait_adaptation_list : trait_adaptation_list trait_adaptation",
        "trait_adaptation : trait_method_reference_fully_qualified T_INSTEADOF name_list ';'",
        "trait_adaptation : trait_method_reference T_AS member_modifier T_STRING ';'",
        "trait_adaptation : trait_method_reference T_AS member_modifier ';'",
        "trait_adaptation : trait_method_reference T_AS T_STRING ';'",
        "trait_method_reference_fully_qualified : name T_PAAMAYIM_NEKUDOTAYIM T_STRING",
        "trait_method_reference : trait_method_reference_fully_qualified",
        "trait_method_reference : T_STRING",
        "method_body : ';'",
        "method_body : '{' inner_statement_list '}'",
        "variable_modifiers : non_empty_member_modifiers",
        "variable_modifiers : T_VAR",
        "method_modifiers : /* empty */",
        "method_modifiers : non_empty_member_modifiers",
        "non_empty_member_modifiers : member_modifier",
        "non_empty_member_modifiers : non_empty_member_modifiers member_modifier",
        "member_modifier : T_PUBLIC",
        "member_modifier : T_PROTECTED",
        "member_modifier : T_PRIVATE",
        "member_modifier : T_STATIC",
        "member_modifier : T_ABSTRACT",
        "member_modifier : T_FINAL",
        "property_declaration_list : property_declaration",
        "property_declaration_list : property_declaration_list ',' property_declaration",
        "property_declaration : T_VARIABLE",
        "property_declaration : T_VARIABLE '=' static_scalar",
        "expr_list : expr_list ',' expr",
        "expr_list : expr",
        "for_expr : /* empty */",
        "for_expr : expr_list",
        "expr : variable",
        "expr : list_expr '=' expr",
        "expr : variable '=' expr",
        "expr : variable '=' '&' variable",
        "expr : variable '=' '&' new_expr",
        "expr : new_expr",
        "expr : T_CLONE expr",
        "expr : variable T_PLUS_EQUAL expr",
        "expr : variable T_MINUS_EQUAL expr",
        "expr : variable T_MUL_EQUAL expr",
        "expr : variable T_DIV_EQUAL expr",
        "expr : variable T_CONCAT_EQUAL expr",
        "expr : variable T_MOD_EQUAL expr",
        "expr : variable T_AND_EQUAL expr",
        "expr : variable T_OR_EQUAL expr",
        "expr : variable T_XOR_EQUAL expr",
        "expr : variable T_SL_EQUAL expr",
        "expr : variable T_SR_EQUAL expr",
        "expr : variable T_INC",
        "expr : T_INC variable",
        "expr : variable T_DEC",
        "expr : T_DEC variable",
        "expr : expr T_BOOLEAN_OR expr",
        "expr : expr T_BOOLEAN_AND expr",
        "expr : expr T_LOGICAL_OR expr",
        "expr : expr T_LOGICAL_AND expr",
        "expr : expr T_LOGICAL_XOR expr",
        "expr : expr '|' expr",
        "expr : expr '&' expr",
        "expr : expr '^' expr",
        "expr : expr '.' expr",
        "expr : expr '+' expr",
        "expr : expr '-' expr",
        "expr : expr '*' expr",
        "expr : expr '/' expr",
        "expr : expr '%' expr",
        "expr : expr T_SL expr",
        "expr : expr T_SR expr",
        "expr : '+' expr",
        "expr : '-' expr",
        "expr : '!' expr",
        "expr : '~' expr",
        "expr : expr T_IS_IDENTICAL expr",
        "expr : expr T_IS_NOT_IDENTICAL expr",
        "expr : expr T_IS_EQUAL expr",
        "expr : expr T_IS_NOT_EQUAL expr",
        "expr : expr '<' expr",
        "expr : expr T_IS_SMALLER_OR_EQUAL expr",
        "expr : expr '>' expr",
        "expr : expr T_IS_GREATER_OR_EQUAL expr",
        "expr : expr T_INSTANCEOF class_name_reference",
        "expr : parentheses_expr",
        "expr : '(' new_expr ')'",
        "expr : expr '?' expr ':' expr",
        "expr : expr '?' ':' expr",
        "expr : T_ISSET '(' variables_list ')'",
        "expr : T_EMPTY '(' expr ')'",
        "expr : T_INCLUDE expr",
        "expr : T_INCLUDE_ONCE expr",
        "expr : T_EVAL parentheses_expr",
        "expr : T_REQUIRE expr",
        "expr : T_REQUIRE_ONCE expr",
        "expr : T_INT_CAST expr",
        "expr : T_DOUBLE_CAST expr",
        "expr : T_STRING_CAST expr",
        "expr : T_ARRAY_CAST expr",
        "expr : T_OBJECT_CAST expr",
        "expr : T_BOOL_CAST expr",
        "expr : T_UNSET_CAST expr",
        "expr : T_EXIT exit_expr",
        "expr : '@' expr",
        "expr : scalar",
        "expr : array_expr",
        "expr : scalar_dereference",
        "expr : '`' backticks_expr '`'",
        "expr : T_PRINT expr",
        "expr : T_YIELD",
        "expr : T_FUNCTION optional_ref '(' parameter_list ')' lexical_vars '{' inner_statement_list '}'",
        "expr : T_STATIC T_FUNCTION optional_ref '(' parameter_list ')' lexical_vars '{' inner_statement_list '}'",
        "parentheses_expr : '(' expr ')'",
        "parentheses_expr : '(' yield_expr ')'",
        "yield_expr : T_YIELD expr",
        "yield_expr : T_YIELD expr T_DOUBLE_ARROW expr",
        "array_expr : T_ARRAY '(' array_pair_list ')'",
        "array_expr : '[' array_pair_list ']'",
        "scalar_dereference : array_expr '[' dim_offset ']'",
        "scalar_dereference : T_CONSTANT_ENCAPSED_STRING '[' dim_offset ']'",
        "scalar_dereference : scalar_dereference '[' dim_offset ']'",
        "new_expr : T_NEW class_name_reference ctor_arguments",
        "lexical_vars : /* empty */",
        "lexical_vars : T_USE '(' lexical_var_list ')'",
        "lexical_var_list : lexical_var",
        "lexical_var_list : lexical_var_list ',' lexical_var",
        "lexical_var : optional_ref T_VARIABLE",
        "function_call : name argument_list",
        "function_call : class_name_or_var T_PAAMAYIM_NEKUDOTAYIM T_STRING argument_list",
        "function_call : class_name_or_var T_PAAMAYIM_NEKUDOTAYIM '{' expr '}' argument_list",
        "function_call : static_property argument_list",
        "function_call : variable_without_objects argument_list",
        "function_call : function_call '[' dim_offset ']'",
        "class_name : T_STATIC",
        "class_name : name",
        "name : namespace_name",
        "name : T_NS_SEPARATOR namespace_name",
        "name : T_NAMESPACE T_NS_SEPARATOR namespace_name",
        "class_name_reference : class_name",
        "class_name_reference : dynamic_class_name_reference",
        "dynamic_class_name_reference : object_access_for_dcnr",
        "dynamic_class_name_reference : base_variable",
        "class_name_or_var : class_name",
        "class_name_or_var : reference_variable",
        "object_access_for_dcnr : /* empty */",
        "object_access_for_dcnr : base_variable T_OBJECT_OPERATOR object_property",
        "object_access_for_dcnr : object_access_for_dcnr T_OBJECT_OPERATOR object_property",
        "object_access_for_dcnr : object_access_for_dcnr '[' dim_offset ']'",
        "object_access_for_dcnr : object_access_for_dcnr '{' expr '}'",
        "exit_expr : /* empty */",
        "exit_expr : '(' ')'",
        "exit_expr : parentheses_expr",
        "backticks_expr : /* empty */",
        "backticks_expr : T_ENCAPSED_AND_WHITESPACE",
        "backticks_expr : encaps_list",
        "ctor_arguments : /* empty */",
        "ctor_arguments : argument_list",
        "common_scalar : T_LNUMBER",
        "common_scalar : T_DNUMBER",
        "common_scalar : T_CONSTANT_ENCAPSED_STRING",
        "common_scalar : T_LINE",
        "common_scalar : T_FILE",
        "common_scalar : T_DIR",
        "common_scalar : T_CLASS_C",
        "common_scalar : T_TRAIT_C",
        "common_scalar : T_METHOD_C",
        "common_scalar : T_FUNC_C",
        "common_scalar : T_NS_C",
        "common_scalar : T_START_HEREDOC T_ENCAPSED_AND_WHITESPACE T_END_HEREDOC",
        "common_scalar : T_START_HEREDOC T_END_HEREDOC",
        "common_scalar : name",
        "static_scalar : common_scalar",
        "static_scalar : class_name T_PAAMAYIM_NEKUDOTAYIM T_STRING",
        "static_scalar : '+' static_scalar",
        "static_scalar : '-' static_scalar",
        "static_scalar : T_ARRAY '(' static_array_pair_list ')'",
        "static_scalar : '[' static_array_pair_list ']'",
        "scalar : common_scalar",
        "scalar : class_name_or_var T_PAAMAYIM_NEKUDOTAYIM T_STRING",
        "scalar : '\"' encaps_list '\"'",
        "scalar : T_START_HEREDOC encaps_list T_END_HEREDOC",
        "static_array_pair_list : /* empty */",
        "static_array_pair_list : non_empty_static_array_pair_list optional_comma",
        "optional_comma : /* empty */",
        "optional_comma : ','",
        "non_empty_static_array_pair_list : non_empty_static_array_pair_list ',' static_array_pair",
        "non_empty_static_array_pair_list : static_array_pair",
        "static_array_pair : static_scalar T_DOUBLE_ARROW static_scalar",
        "static_array_pair : static_scalar",
        "variable : object_access",
        "variable : base_variable",
        "variable : function_call",
        "variable : new_expr_array_deref",
        "new_expr_array_deref : '(' new_expr ')' '[' dim_offset ']'",
        "new_expr_array_deref : new_expr_array_deref '[' dim_offset ']'",
        "object_access : variable_or_new_expr T_OBJECT_OPERATOR object_property",
        "object_access : variable_or_new_expr T_OBJECT_OPERATOR object_property argument_list",
        "object_access : object_access argument_list",
        "object_access : object_access '[' dim_offset ']'",
        "object_access : object_access '{' expr '}'",
        "variable_or_new_expr : variable",
        "variable_or_new_expr : '(' new_expr ')'",
        "variable_without_objects : reference_variable",
        "variable_without_objects : '$' variable_without_objects",
        "base_variable : variable_without_objects",
        "base_variable : static_property",
        "static_property : class_name_or_var T_PAAMAYIM_NEKUDOTAYIM '$' reference_variable",
        "static_property : static_property_with_arrays",
        "static_property_with_arrays : class_name_or_var T_PAAMAYIM_NEKUDOTAYIM T_VARIABLE",
        "static_property_with_arrays : class_name_or_var T_PAAMAYIM_NEKUDOTAYIM '$' '{' expr '}'",
        "static_property_with_arrays : static_property_with_arrays '[' dim_offset ']'",
        "static_property_with_arrays : static_property_with_arrays '{' expr '}'",
        "reference_variable : reference_variable '[' dim_offset ']'",
        "reference_variable : reference_variable '{' expr '}'",
        "reference_variable : T_VARIABLE",
        "reference_variable : '$' '{' expr '}'",
        "dim_offset : /* empty */",
        "dim_offset : expr",
        "object_property : T_STRING",
        "object_property : '{' expr '}'",
        "object_property : variable_without_objects",
        "list_expr : T_LIST '(' list_expr_elements ')'",
        "list_expr_elements : list_expr_elements ',' list_expr_element",
        "list_expr_elements : list_expr_element",
        "list_expr_element : variable",
        "list_expr_element : list_expr",
        "list_expr_element : /* empty */",
        "array_pair_list : /* empty */",
        "array_pair_list : non_empty_array_pair_list optional_comma",
        "non_empty_array_pair_list : non_empty_array_pair_list ',' array_pair",
        "non_empty_array_pair_list : array_pair",
        "array_pair : expr T_DOUBLE_ARROW expr",
        "array_pair : expr",
        "array_pair : expr T_DOUBLE_ARROW '&' variable",
        "array_pair : '&' variable",
        "encaps_list : encaps_list encaps_var",
        "encaps_list : encaps_list T_ENCAPSED_AND_WHITESPACE",
        "encaps_list : encaps_var",
        "encaps_list : T_ENCAPSED_AND_WHITESPACE encaps_var",
        "encaps_var : T_VARIABLE",
        "encaps_var : T_VARIABLE '[' encaps_var_offset ']'",
        "encaps_var : T_VARIABLE T_OBJECT_OPERATOR T_STRING",
        "encaps_var : T_DOLLAR_OPEN_CURLY_BRACES expr '}'",
        "encaps_var : T_DOLLAR_OPEN_CURLY_BRACES T_STRING_VARNAME '}'",
        "encaps_var : T_DOLLAR_OPEN_CURLY_BRACES T_STRING_VARNAME '[' expr ']' '}'",
        "encaps_var : T_CURLY_OPEN variable '}'",
        "encaps_var_offset : T_STRING",
        "encaps_var_offset : T_NUM_STRING",
        "encaps_var_offset : T_VARIABLE"
    );

    protected function yyprintln($msg) {
        echo $msg, "\n";
    }

    protected function YYTRACE_NEWSTATE($state, $tokenId) {
        $this->yyprintln(
            '% State ' . $state
          . ', Lookahead ' . ($tokenId == self::TOKEN_NONE ? '--none--' : self::$terminals[$tokenId])
        );
    }

    protected function YYTRACE_READ($tokenId) {
        $this->yyprintln('% Reading ' . self::$terminals[$tokenId]);
    }

    protected function YYTRACE_SHIFT($tokenId) {
        $this->yyprintln('% Shift ' . self::$terminals[$tokenId]);
    }

    protected function YYTRACE_ACCEPT() {
        $this->yyprintln('% Accepted.');
    }

    protected function YYTRACE_REDUCE($n) {
        $this->yyprintln('% Reduce by (' . $n . ') ' . self::$yyproduction[$n]);
    }

    protected function YYTRACE_POP($state) {
        $this->yyprintln('% Recovering, uncovers state ' . $state);
    }

    protected function YYTRACE_DISCARD($tokenId) {
        $this->yyprintln('% Discard ' . self::$terminals[$tokenId]);
    }

    /**
     * Parses PHP code into a node tree and prints out debugging information.
     *
     * @param string $code The source code to parse
     *
     * @return array Array of statements
     */
    public function parse($code) {
        $this->lexer->startLexing($code);

        // We start off with no lookahead-token
        $tokenId = self::TOKEN_NONE;

        // The attributes for a node are taken from the first and last token of the node.
        // From the first token only the startAttributes are taken and from the last only
        // the endAttributes. Both are merged using the array union operator (+).
        $startAttributes = array('startLine' => 1);
        $endAttributes   = array();

        // In order to figure out the attributes for the starting token, we have to keep
        // them in a stack
        $attributeStack = array($startAttributes);

        // Start off in the initial state and keep a stack of previous states
        $state = 0;
        $stateStack = array($state);

        // AST stack (?)
        $this->yyastk = array();

        // Current position in the stack(s)
        $this->stackPos = 0;

        for (;;) {
            $this->YYTRACE_NEWSTATE($state, $tokenId);

            if (self::$yybase[$state] == 0) {
                $yyn = self::$yydefault[$state];
            } else {
                if ($tokenId === self::TOKEN_NONE) {
                    // fetch the next token id from the lexer and fetch additional info by-ref
                    $origTokenId = $this->lexer->getNextToken($tokenValue, $startAttributes, $endAttributes);

                    // map the lexer token id to the internally used token id's
                    $tokenId = $origTokenId >= 0 && $origTokenId < self::TOKEN_MAP_SIZE
                        ? self::$translate[$origTokenId]
                        : self::TOKEN_INVALID;

                    if ($tokenId === self::TOKEN_INVALID) {
                        throw new RangeException(sprintf(
                            'The lexer returned an invalid token (id=%d, value=%s)',
                            $origTokenId, $tokenValue
                        ));
                    }

                    $attributeStack[$this->stackPos] = $startAttributes;

                    $this->YYTRACE_READ($tokenId);
                }

                if ((($yyn = self::$yybase[$state] + $tokenId) >= 0
                     && $yyn < self::YYLAST && self::$yycheck[$yyn] == $tokenId
                     || ($state < self::YY2TBLSTATE
                        && ($yyn = self::$yybase[$state + self::YYNLSTATES] + $tokenId) >= 0
                        && $yyn < self::YYLAST
                        && self::$yycheck[$yyn] == $tokenId))
                    && ($yyn = self::$yyaction[$yyn]) != self::YYDEFAULT) {
                    /*
                     * >= YYNLSTATE: shift and reduce
                     * > 0: shift
                     * = 0: accept
                     * < 0: reduce
                     * = -YYUNEXPECTED: error
                     */
                    if ($yyn > 0) {
                        /* shift */
                        $this->YYTRACE_SHIFT($tokenId);

                        ++$this->stackPos;

                        $stateStack[$this->stackPos]     = $state = $yyn;
                        $this->yyastk[$this->stackPos]   = $tokenValue;
                        $attributeStack[$this->stackPos] = $startAttributes;
                        $tokenId = self::TOKEN_NONE;

                        if ($yyn < self::YYNLSTATES)
                            continue;

                        /* $yyn >= YYNLSTATES means shift-and-reduce */
                        $yyn -= self::YYNLSTATES;
                    } else {
                        $yyn = -$yyn;
                    }
                } else {
                    $yyn = self::$yydefault[$state];
                }
            }

            for (;;) {
                /* reduce/error */
                if ($yyn == 0) {
                    /* accept */
                    $this->YYTRACE_ACCEPT();
                    return $this->yyval;
                } elseif ($yyn != self::YYUNEXPECTED) {
                    /* reduce */
                    $this->YYTRACE_REDUCE($yyn);
                    try {
                        $this->{'yyn' . $yyn}(
                            $attributeStack[$this->stackPos - self::$yylen[$yyn]]
                            + $endAttributes
                        );
                    } catch (PHPParser_Error $e) {
                        if (-1 === $e->getRawLine()) {
                            $e->setRawLine($startAttributes['startLine']);
                        }

                        throw $e;
                    }

                    /* Goto - shift nonterminal */
                    $this->stackPos -= self::$yylen[$yyn];
                    $yyn = self::$yylhs[$yyn];
                    if (($yyp = self::$yygbase[$yyn] + $stateStack[$this->stackPos]) >= 0
                         && $yyp < self::YYGLAST
                         && self::$yygcheck[$yyp] == $yyn) {
                        $state = self::$yygoto[$yyp];
                    } else {
                        $state = self::$yygdefault[$yyn];
                    }

                    ++$this->stackPos;

                    $stateStack[$this->stackPos]     = $state;
                    $this->yyastk[$this->stackPos]   = $this->yyval;
                    $attributeStack[$this->stackPos] = $startAttributes;
                } else {
                    /* error */
                    throw new PHPParser_Error(
                        'Unexpected token ' . self::$terminals[$tokenId],
                        $startAttributes['startLine']
                    );
                }

                if ($state < self::YYNLSTATES)
                    break;
                /* >= YYNLSTATES means shift-and-reduce */
                $yyn = $state - self::YYNLSTATES;
            }
        }
    }
}
