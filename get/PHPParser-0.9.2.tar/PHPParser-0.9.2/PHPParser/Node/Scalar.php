<?php

abstract class PHPParser_Node_Scalar extends PHPParser_Node_Expr
{
}